package viaduct.engine.runtime2.execution

import graphql.GraphQLContext
import graphql.execution.ExecutionContext
import graphql.schema.GraphQLSchema
import viaduct.engine.runtime2.model.SelectionForest
import viaduct.engine.runtime2.model.registry.Assumptions
import viaduct.engine.runtime2.schema.selectionsFrom

/** Supplies construction demand from an already validated operation. */
interface Runtime2OperationSelectionProvider {
    /** Applied before validation; preparsed caches must retain any requested validation artifact. */
    fun configureContext(context: GraphQLContext.Builder) {}

    fun selections(
        world: Assumptions,
        sourceSchema: GraphQLSchema,
        context: ExecutionContext,
    ): SelectionForest

    companion object {
        val AST: Runtime2OperationSelectionProvider = AstOperationSelectionProvider
    }
}

private object AstOperationSelectionProvider : Runtime2OperationSelectionProvider {
    override fun selections(
        world: Assumptions,
        sourceSchema: GraphQLSchema,
        context: ExecutionContext,
    ): SelectionForest =
        world.selectionsFrom(
            sourceSchema = sourceSchema,
            operation = context.operationDefinition,
            variables = context.coercedVariables,
            graphQLContext = context.graphQLContext,
            locale = context.locale,
            fragmentsByName = context.fragmentsByName,
        )
}
