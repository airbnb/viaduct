package viaduct.engine.runtime2.execution

import graphql.ExecutionResult
import graphql.execution.AsyncExecutionStrategy
import graphql.execution.DataFetcherExceptionHandler
import graphql.execution.ExecutionContext
import graphql.execution.ExecutionId
import graphql.execution.ExecutionStrategyParameters
import graphql.execution.SimpleDataFetcherExceptionHandler
import graphql.incremental.DelayedIncrementalPartialResult
import graphql.incremental.IncrementalExecutionResult
import graphql.incremental.IncrementalExecutionResultImpl
import graphql.language.OperationDefinition
import graphql.schema.GraphQLSchema
import java.util.concurrent.CancellationException
import java.util.concurrent.CompletableFuture
import java.util.concurrent.atomic.AtomicReference
import kotlin.coroutines.CoroutineContext
import kotlinx.coroutines.CoroutineExceptionHandler
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Job
import kotlinx.coroutines.future.future
import org.reactivestreams.Publisher
import org.reactivestreams.Subscriber
import org.reactivestreams.Subscription
import viaduct.engine.api.Engine
import viaduct.engine.api.EngineExecutionContext
import viaduct.engine.runtime2.model.registry.Assumptions
import viaduct.engine.runtime2.model.requireQueryTypeDef
import viaduct.engine.runtime2.resolution.framework.CycleCheckState
import viaduct.engine.runtime2.resolution.framework.ResolutionObserver
import viaduct.engine.runtime2.resolution.framework.SharedOperationContext
import viaduct.engine.runtime2.resolution.startResolution

/**
 * GraphQL operation execution boundary for the runtime2 GraphQL-Java harness.
 *
 * Each request decodes its validated operation into runtime2 selections, starts Resolution, and
 * delegates GraphQL completion with a live promise-backed OER as the root source.
 * The resolver context is borrowed; the strategy owns only its request job.
 * [RequestLifetimeInstrumentation] must be installed on the enclosing `GraphQL` instance so incremental
 * publisher termination owns final request cleanup.
 */
class Runtime2ExecutionStrategy(
    private val world: Assumptions,
    private val sourceSchema: GraphQLSchema,
    private val resolverCoroutineContext: CoroutineContext,
    private val engineExecutionContextFactory: (ExecutionContext) -> EngineExecutionContext? = { null },
    dataFetcherExceptionHandler: DataFetcherExceptionHandler =
        SimpleDataFetcherExceptionHandler(),
    private val operationSelectionProvider: Runtime2OperationSelectionProvider = Runtime2OperationSelectionProvider.AST,
) : AsyncExecutionStrategy(dataFetcherExceptionHandler) {
    private val resolverExceptionHandler = dataFetcherExceptionHandler

    override fun execute(
        executionContext: ExecutionContext,
        parameters: ExecutionStrategyParameters,
    ): CompletableFuture<ExecutionResult> {
        val selections = operationSelectionProvider.selections(world, sourceSchema, executionContext)

        val requestJob = Job()
        executionContext.graphQLContext
            .get<Runtime2CallerCancellation>(Runtime2CallerCancellationKey)
            ?.attach(requestJob)
        val requestFailure = CompletableFuture<Throwable>()
        val cycleChecker = executionContext.graphQLContext.get<CycleCheckState>(CycleCheckState::class.java)
            ?: CycleCheckState.create()
        // The independent job lets incremental work outlive initial response completion.
        val requestScope =
            CoroutineScope(
                resolverCoroutineContext +
                    requestJob +
                    CoroutineExceptionHandler { _, throwable ->
                        requestFailure.complete(throwable)
                    },
            )
        val lifetimeKey = Runtime2RequestLifetimeKey(executionContext.executionId)
        executionContext.graphQLContext.put(
            lifetimeKey,
            Runtime2RequestLifetime(requestJob),
        )

        val resolution =
            try {
                SharedOperationContext.create(
                    world,
                    engineExecutionContext = engineExecutionContextFactory(executionContext),
                    resolutionObserver = executionContext.graphQLContext.getOrDefault<ResolutionObserver>(
                        ResolutionObserver::class.java,
                        ResolutionObserver.NOP,
                    ),
                ).startResolution(
                    selections,
                    requestScope,
                    cycleChecker,
                    rootType = if (executionContext.operationDefinition.operation == OperationDefinition.Operation.SUBSCRIPTION) {
                        requireNotNull(world.schema.subscriptionTypeDef)
                    } else {
                        world.schema.requireQueryTypeDef()
                    },
                )
            } catch (throwable: Exception) {
                executionContext.graphQLContext.delete(lifetimeKey)
                requestJob.cancel(requestCancellation("Runtime2 request failed to start", throwable))
                throw throwable
            }

        val graphqlFuture =
            try {
                val completionParameters =
                    parameters.transform { builder ->
                        builder.source(Runtime2ExecutionSource(resolution.root, requestScope, resolverExceptionHandler))
                    }
                if (executionContext.operationDefinition.operation == OperationDefinition.Operation.MUTATION) {
                    // Null propagation can finish GraphQL completion early. Every mutation must
                    // finish before that completion is allowed to terminate the request.
                    requestScope.future { resolution.await() }
                        .thenCompose { super.execute(executionContext, completionParameters) }
                } else {
                    super.execute(executionContext, completionParameters)
                }
            } catch (throwable: Exception) {
                executionContext.graphQLContext.delete(lifetimeKey)
                requestJob.cancel(requestCancellation("GraphQL completion failed", throwable))
                throw throwable
            }
        val resultFuture = CompletableFuture<ExecutionResult>()
        graphqlFuture.whenComplete { result, throwable ->
            val resolverFailure = requestFailure.getNow(null)
            if (resolverFailure != null) {
                executionContext.graphQLContext.delete(lifetimeKey)
                resultFuture.completeExceptionally(resolverFailure)
            } else if (throwable != null) {
                executionContext.graphQLContext.delete(lifetimeKey)
                requestJob.cancel(requestCancellation("GraphQL completion failed", throwable))
                resultFuture.completeExceptionally(throwable)
            } else if (result is IncrementalExecutionResult) {
                executionContext.graphQLContext.delete(lifetimeKey)
                resultFuture.complete(result.withRequestLifetime(requestJob))
            } else {
                resultFuture.complete(result)
                if (!executionContext.incrementalCallState.incrementalCallsDetected) {
                    executionContext.graphQLContext.delete(lifetimeKey)
                    requestJob.cancel(requestCancellation("GraphQL request completed"))
                }
            }
        }
        requestFailure.thenAccept { throwable ->
            executionContext.graphQLContext.delete(lifetimeKey)
            resultFuture.completeExceptionally(throwable)
        }
        resultFuture.whenComplete { _, _ ->
            if (resultFuture.isCancelled) {
                graphqlFuture.cancel(true)
                requestJob.cancel(requestCancellation("GraphQL execution future cancelled"))
            }
        }
        return resultFuture
    }
}

internal fun IncrementalExecutionResult.withRequestLifetime(requestJob: Job): IncrementalExecutionResult {
    val original = incrementalItemPublisher
    val wrapped =
        Publisher<DelayedIncrementalPartialResult> { downstream ->
            try {
                original.subscribe(
                    object : Subscriber<DelayedIncrementalPartialResult> {
                        override fun onSubscribe(subscription: Subscription) {
                            downstream.onSubscribe(
                                object : Subscription {
                                    override fun request(count: Long) = subscription.request(count)

                                    override fun cancel() {
                                        try {
                                            subscription.cancel()
                                        } finally {
                                            requestJob.cancel(
                                                requestCancellation(
                                                    "Incremental subscriber cancelled",
                                                ),
                                            )
                                        }
                                    }
                                },
                            )
                        }

                        override fun onNext(item: DelayedIncrementalPartialResult) = downstream.onNext(item)

                        override fun onError(throwable: Throwable) {
                            try {
                                downstream.onError(throwable)
                            } finally {
                                requestJob.cancel(
                                    requestCancellation(
                                        "Incremental publisher failed",
                                        throwable,
                                    ),
                                )
                            }
                        }

                        override fun onComplete() {
                            try {
                                downstream.onComplete()
                            } finally {
                                requestJob.cancel(
                                    requestCancellation("Incremental publisher completed"),
                                )
                            }
                        }
                    },
                )
            } catch (throwable: Exception) {
                requestJob.cancel(
                    requestCancellation("Incremental publisher subscription failed", throwable),
                )
                throw throwable
            }
        }
    return IncrementalExecutionResultImpl
        .fromIncrementalExecutionResult(this)
        .incrementalItemPublisher(wrapped)
        .build()
}

internal fun requestCancellation(
    message: String,
    cause: Throwable? = null,
): CancellationException =
    CancellationException(message).also { cancellation ->
        if (cause != null) cancellation.initCause(cause)
    }

internal data class Runtime2RequestLifetime(
    val requestJob: Job,
)

internal data class Runtime2RequestLifetimeKey(
    val executionId: ExecutionId,
)

/**
 * Propagates caller cancellation into an independently owned request job.
 *
 * The request job cannot be a structured child of the caller: an incremental result must outlive
 * the initial [Engine.execute] call until its publisher ends.
 */
internal class Runtime2CallerCancellation {
    private val requestJob = AtomicReference<Job?>()
    private val cancellation = AtomicReference<CancellationException?>()

    fun attach(job: Job) {
        check(requestJob.compareAndSet(null, job)) { "Runtime2 caller cancellation already has an active request job" }
        job.invokeOnCompletion { requestJob.compareAndSet(job, null) }
        cancellation.get()?.let(job::cancel)
    }

    fun cancel(cause: CancellationException) {
        cancellation.compareAndSet(null, cause)
        requestJob.get()?.cancel(requireNotNull(cancellation.get()))
    }
}

internal data object Runtime2CallerCancellationKey
