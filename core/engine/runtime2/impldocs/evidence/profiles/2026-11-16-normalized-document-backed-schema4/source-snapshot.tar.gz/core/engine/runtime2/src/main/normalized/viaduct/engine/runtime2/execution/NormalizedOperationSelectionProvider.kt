package viaduct.engine.runtime2.execution

import graphql.GraphQLContext
import graphql.execution.ExecutionContext
import graphql.language.OperationDefinition
import graphql.normalized.NormalizedDocument
import graphql.schema.GraphQLSchema
import viaduct.engine.runtime2.model.SelectionForest
import viaduct.engine.runtime2.model.registry.Assumptions
import viaduct.engine.runtime2.schema.NormalizedSelectionSource

/**
 * Opt-in integration with graphql-java PR 4562. Queries and subscriptions retain the validated
 * graph; mutations use the existing response-ordered conversion. Missing cached graphs fail
 * explicitly rather than being rebuilt after validation.
 */
object NormalizedOperationSelectionProvider : Runtime2OperationSelectionProvider {
    override fun configureContext(context: GraphQLContext.Builder) {
        context.put(NormalizedDocument.ENABLED, true)
    }

    override fun selections(
        world: Assumptions,
        sourceSchema: GraphQLSchema,
        context: ExecutionContext,
    ): SelectionForest {
        if (context.operationDefinition.operation == OperationDefinition.Operation.MUTATION) {
            return Runtime2OperationSelectionProvider.AST.selections(world, sourceSchema, context)
        }
        val document = requireNotNull(context.normalizedDocument) {
            "Enable NormalizedDocument before validation and retain it in the preparsed cache"
        }
        return NormalizedSelectionSource(
            document, sourceSchema, world.schema, context.coercedVariables, context.graphQLContext, context.locale,
        ).selections(context.operationDefinition)
    }
}
