# Normalized Document Construction Demand

Runtime2 can consume graphql-java PR [#4562](https://github.com/graphql-java/graphql-java/pull/4562)'s validated `NormalizedDocument` through `NormalizedOperationSelectionProvider`. This is an opt-in integration with the pinned PR jar, not a change to the repository's default graphql-java dependency. The implementation is in `src/main/normalized`; the regular build retains `Runtime2OperationSelectionProvider.AST` as its default.

## Execution Boundary

Pass `operationSelectionProvider = NormalizedOperationSelectionProvider` to `Engine2` or `Runtime2ExecutionStrategy`. `Engine2.execute` configures the GraphQL context before validation. Callers using the lower-level strategy or `getGraphQL()` directly must call the provider's `configureContext` from the `ExecutionInput` builder's `graphQLContext` callback. Preparsing providers must retain the complete successful `PreparsedDocumentEntry` and distinguish schemas and ND creation options. The incremental-label-validation wrapper retains successful entries. A missing ND fails explicitly instead of triggering another document conversion.

Queries and subscriptions create a request-local `NormalizedSelectionSource` and a deferred root forest. Selecting the root searches the ND operation list by AST identity without walking its selection graph. Observing a forest collects its immediate value level; named and inline fragment scopes are traversed iteratively at that level. Child selections retain deferred references indexed by ND selection-set ID and possible object types. Argument decoding is cached by normalized field within this request's variables, GraphQL context, locale, and schema mapping. Neither cache is stored in the shared ND or reused across requests.

The adapter preserves aliases' construction-key equivalence, canonical schema lowering, concrete-type applicability, argument defaults, excluded-selection guards, and introspection erasure. Merge and guard operations retain deferred child contributions instead of collecting them merely to combine parent fields. Subsequent collection continues to use Runtime2's existing concrete-field specialization and key-merging rules. There is no new result-occurrence identity or resolver deduplication rule.

Mutation operations retain the existing response-ordered AST conversion. Resolver/checker materialization templates and nested execution keep their current representation. Successor-demand analysis still recursively computes producer requirements; this integration removes eager request-forest expansion and shares collected child forests, but does not eliminate every downstream traversal or rewrite that algorithm. GraphQL completion and incremental-label validation also retain their existing behavior.

## Build And Verification

The PR removes APIs still used by the older `runtime` engine. The experiment substitutes the PR jar only in Runtime2 configurations; other modules compile against the published dependency. The build property `gjNormalizedDocumentBenchmark` includes `src/main/normalized`, `src/testNormalized/kotlin`, and `src/jmhNormalized/kotlin`. This setup supports the isolated integration and benchmarks; it is not a repository-wide dependency migration or a publication configuration for general consumers.

```sh
core/engine/runtime2/scripts/build-normalized-document-benchmark.sh /path/to/graphql-java-0.0.0-HEAD-SNAPSHOT.jar \
  :core:engine:runtime2:test --tests '*NormalizedOperationSelectionsTest' \
  --tests '*DeferredSelectionForestTest' --tests '*SelectionMergeTest' \
  --tests '*SelectionForestConcatenationTest' --no-configuration-cache
```

Tests independently compare selections against the existing AST parser and execute through production Resolution. They cover shared descendant identity, deferred argument decoding, aliases and conditions, abstract-type intersections, Node lowering, defaults and nulls, concurrent readers, different variables using a cached ND, selected operation identity, subscriptions, mutation fallback, long fragment chains, and preparsed entries that discard ND. The default Runtime2 check verifies the unchanged default build and the shared model changes.

The [benchmark guide](../testing/normalized-document-benchmark.md) distinguishes initial view creation from complete forest consumption. Full traversal benchmarks deliberately visit every logical occurrence, including repeated shared descendants, so deferred work is included in the timed region. They do not measure resolver execution or response completion.
