#!/usr/bin/env bash
set -euo pipefail

if [[ $# -ne 2 ]]; then
    echo "Usage: $0 JMH_JAR RESULT_DIRECTORY" >&2
    exit 2
fi

jar=$(realpath "$1")
result_dir=$2
mkdir -p "$result_dir"
result_dir=$(realpath "$result_dir")
script_dir=$(dirname "$(realpath "$0")")
host_state="$result_dir/host-original-state.json"

exec 9>/opt/graphql-schema-perf/benchmark.lock
if ! flock -n 9; then
    echo "Hetzner benchmark lock is held; no JMH process was started" >&2
    exit 75
fi

restore_host() {
    rc=$?
    trap - EXIT
    if [[ -f "$host_state" ]]; then
        if ! python3 "$script_dir/selection-forest-benchmark-host-settings.py" restore "$host_state"; then
            echo "Host setting restoration failed; inspect $host_state" >&2
            rc=1
        fi
    fi
    exit "$rc"
}
trap restore_host EXIT

python3 "$script_dir/selection-forest-benchmark-host-settings.py" prepare "$host_state"
{
    date -u '+Started: %Y-%m-%dT%H:%M:%SZ'
    java -version 2>&1
    sha256sum "$jar"
    uname -a
    echo 'GraphQL Java PR 4562 head: 69c7bfbef920e5b95b7c295b60ef0652523eef3d'
    echo 'Cases: 6 methods x 2 forks'
    echo 'Per fork: 2 warmup x 30s + 3 measurement x 60s = 240s'
    echo 'Scheduled JMH iteration time: 2880s (48m)'
    echo 'Wall-clock deadline for JMH, including fork setup: 70m plus 30s termination grace'
} > "$result_dir/metadata.txt"

timeout --signal=TERM --kill-after=30s 70m \
    java -cp "$jar" org.openjdk.jmh.Main \
        'viaduct.engine.runtime2.schema.NormalizedDocumentSelectionBenchmark.*' \
        -t 1 -prof gc -rf json -rff "$result_dir/results.json" \
    2>&1 | tee "$result_dir/jmh.log"

python3 - "$result_dir/results.json" <<'PY'
import json
import sys

results = json.load(open(sys.argv[1]))
if len(results) != 6:
    raise SystemExit(f"Expected 6 benchmark results, found {len(results)}")
print("Verified 6 benchmark results")
PY
