package viaduct.engine.runtime2.schema

import graphql.GraphQLContext
import graphql.execution.CoercedVariables
import graphql.execution.ValuesResolver
import graphql.execution.conditional.ConditionalNodes
import graphql.introspection.Introspection
import graphql.language.BooleanValue
import graphql.language.DirectivesContainer
import graphql.language.Document
import graphql.language.Field
import graphql.language.FragmentDefinition
import graphql.language.FragmentSpread
import graphql.language.InlineFragment
import graphql.language.OperationDefinition
import graphql.language.SelectionSet
import graphql.language.VariableReference
import graphql.parser.Parser
import graphql.schema.GraphQLCompositeType
import graphql.schema.GraphQLFieldDefinition
import graphql.schema.GraphQLSchema
import graphql.schema.GraphQLTypeUtil
import graphql.validation.ValidationErrorType
import graphql.validation.Validator
import java.util.Locale
import viaduct.engine.api.FieldDirectives
import viaduct.engine.runtime2.model.Arguments
import viaduct.engine.runtime2.model.EngineInputData
import viaduct.engine.runtime2.model.Fragment
import viaduct.engine.runtime2.model.InclusionCondition
import viaduct.engine.runtime2.model.MaterializeSelectionForest
import viaduct.engine.runtime2.model.ResolverTarget
import viaduct.engine.runtime2.model.SelectionForest
import viaduct.engine.runtime2.model.requireQueryTypeDef
import viaduct.engine.runtime2.model.requireType
import viaduct.engine.runtime2.model.spec.SpecSelection
import viaduct.engine.runtime2.model.spec.flatten
import viaduct.engine.runtime2.model.spec.flattenForMaterialization
import viaduct.engine.runtime2.schema.lowering.loweredFieldFromSourceCoordinate
import viaduct.graphql.schema.ViaductSchema
import viaduct.graphql.utils.SelectionsParserUtils

/**
 * Validates and decodes GraphQL fragment text or ASTs against the unaugmented source schema.
 *
 * Decoded selections are mapped directly to canonical definitions in [schema]. Node-valued source
 * fields retain their source coordinates.
 */
internal class GJSelectionParser(
    private val sourceSchema: GraphQLSchema,
    private val schema: ViaductSchema,
    private val variableValues: Map<String, EngineInputData?>,
    private val variableTarget: ResolverTarget? = null,
    private val preserveSourceResponseKeys: Boolean = false,
) {
    fun selectionsFrom(fragment: String): Pair<ViaductSchema.CompositeTypeDef, SelectionForest> {
        val parsed = specSelectionsFrom(fragment)
        val selections = flatten(schema, parsed.nominalType, parsed.selections)
        return parsed.nominalType to selections
    }

    fun selectionsFrom(
        operation: OperationDefinition,
        variables: CoercedVariables,
        graphQLContext: GraphQLContext,
        locale: Locale,
        fragmentsByName: Map<String, FragmentDefinition> = emptyMap(),
    ): SelectionForest {
        val mutation = operation.operation == OperationDefinition.Operation.MUTATION
        val subscription = operation.operation == OperationDefinition.Operation.SUBSCRIPTION
        val selections = decodeOperationSelections(operation, variables, graphQLContext, locale, fragmentsByName)
        return if (mutation) {
            val type = requireNotNull(schema.mutationTypeDef)
            flattenForMaterialization(schema, type, selections).mutationSelections(schema, type)
        } else {
            val root = if (subscription) requireNotNull(schema.subscriptionTypeDef) else schema.requireQueryTypeDef()
            flatten(schema, root, selections)
        }
    }

    /** Decodes a validated operation into source selections before lowering its scope and keys. */
    internal fun decodeOperationSelections(
        operation: OperationDefinition,
        variables: CoercedVariables,
        graphQLContext: GraphQLContext,
        locale: Locale,
        fragmentsByName: Map<String, FragmentDefinition> = emptyMap(),
    ): List<SpecSelection> {
        val mutation = operation.operation == OperationDefinition.Operation.MUTATION
        val subscription = operation.operation == OperationDefinition.Operation.SUBSCRIPTION
        val sourceRoot = when {
            mutation -> requireNotNull(sourceSchema.mutationType)
            subscription -> requireNotNull(sourceSchema.subscriptionType)
            else -> sourceSchema.queryType
        }
        return decodeSelectionSet(
            selectionSet = operation.selectionSet,
            typeInScope = sourceRoot,
            argumentDecoder =
                CoercedArgumentDecoder(
                    variables = variables,
                    graphQLContext = graphQLContext,
                    locale = locale,
                ),
            mode = TranslationMode.EXTERNAL_OPERATION,
            fragmentsByName = fragmentsByName,
        )
    }

    fun materializeSelectionsFrom(fragment: String): Pair<ViaductSchema.CompositeTypeDef, MaterializeSelectionForest> {
        val parsed = specSelectionsFrom(fragment)
        return parsed.nominalType to parsed.fragment.materializeSelections
    }

    fun specSelectionsFrom(fragment: String): ParsedSpecFragment {
        val document = Parser.parse(fragment)
        require(document.definitions.singleOrNull() is FragmentDefinition) {
            "Expected exactly one named fragment definition"
        }
        return specSelectionsFrom(document)
    }

    fun specSelectionsFrom(document: Document): ParsedSpecFragment {
        val fragments = document.getDefinitionsOfType(FragmentDefinition::class.java)
        require(fragments.size == document.definitions.size) {
            "A resolver selection document may contain only fragment definitions"
        }
        val fragmentsByName = fragments.associateBy(FragmentDefinition::getName)
        require(fragmentsByName.size == fragments.size) {
            "A resolver selection document may not contain duplicate fragment definitions"
        }
        validateFragment(document)
        val definition = SelectionsParserUtils.findEntryPointFragment(fragments)

        val typeConditionName = definition.typeCondition.name!!
        val typeCondition = schema.requireType(typeConditionName) as ViaductSchema.CompositeTypeDef
        val graphQLTypeCondition =
            sourceSchema.getType(typeConditionName) as GraphQLCompositeType
        val specSelections =
            decodeSelectionSet(
                selectionSet = definition.selectionSet,
                typeInScope = graphQLTypeCondition,
                argumentDecoder = LiteralArgumentDecoder(),
                mode = TranslationMode.INTERNAL_FRAGMENT,
                fragmentsByName = fragmentsByName,
            )
        return ParsedSpecFragment(typeCondition, specSelections, schema)
    }

    private fun validateFragment(document: Document) {
        val errors =
            Validator()
                .validateDocument(sourceSchema, document, Locale.ENGLISH)
                .filterNot { it.validationErrorType in STANDALONE_FRAGMENT_ERRORS }
        require(errors.isEmpty()) {
            errors.joinToString(
                prefix = "Invalid GraphQL fragment: ",
                separator = "; ",
            ) { it.message }
        }
    }

    private fun decodeSelectionSet(
        selectionSet: SelectionSet,
        typeInScope: GraphQLCompositeType,
        argumentDecoder: ArgumentDecoder,
        mode: TranslationMode,
        fragmentsByName: Map<String, FragmentDefinition> = emptyMap(),
    ): List<SpecSelection> =
        selectionSet.selections.flatMap { selection ->
            when (selection) {
                is Field ->
                    listOfNotNull(
                        decodeField(
                            selection,
                            typeInScope,
                            argumentDecoder,
                            mode,
                            fragmentsByName,
                        ),
                    )
                is InlineFragment ->
                    listOfNotNull(
                        decodeInlineFragment(
                            fragment = selection,
                            typeInScope = typeInScope,
                            argumentDecoder = argumentDecoder,
                            mode = mode,
                            fragmentsByName = fragmentsByName,
                        ),
                    )
                is FragmentSpread -> {
                    val fragment =
                        fragmentsByName[selection.name]
                            ?: throw IllegalArgumentException(
                                "Missing named fragment definition: ${selection.name}",
                            )
                    listOfNotNull(
                        decodeNamedFragment(
                            fragment = fragment,
                            inclusionCondition = argumentDecoder.decodeCondition(selection),
                            argumentDecoder = argumentDecoder,
                            mode = mode,
                            fragmentsByName = fragmentsByName,
                        ),
                    )
                }
                else -> throw IllegalArgumentException("Unexpected GraphQL selection: $selection")
            }
        }

    private fun decodeField(
        field: Field,
        typeInScope: GraphQLCompositeType,
        argumentDecoder: ArgumentDecoder,
        mode: TranslationMode,
        fragmentsByName: Map<String, FragmentDefinition>,
    ): SpecSelection.Field? {
        if (mode == TranslationMode.EXTERNAL_OPERATION && field.name in Introspection.INTROSPECTION_SYSTEM_FIELDS) {
            return null
        }
        val fieldDefinition =
            Introspection.getFieldDef(
                sourceSchema,
                typeInScope,
                field.name,
            )!!
        val arguments = argumentDecoder.decode(field, fieldDefinition)
        val subselections =
            field.selectionSet?.let { selectionSet ->
                val resultType =
                    GraphQLTypeUtil.unwrapAll(fieldDefinition.type) as GraphQLCompositeType
                decodeSelectionSet(
                    selectionSet,
                    resultType,
                    argumentDecoder,
                    mode,
                    fragmentsByName,
                )
            }
        val canonicalField = schema.loweredFieldFromSourceCoordinate(typeInScope.name, field.name)
        return SpecSelection.Field.of(
            alias =
                field.alias ?: field.name.takeIf {
                    preserveSourceResponseKeys && canonicalField.name != field.name
                },
            field = canonicalField,
            arguments = arguments,
            subselections = subselections,
            inclusionCondition = argumentDecoder.decodeCondition(field),
            fieldDirectives = ParsedFieldDirectives(field.directives.map { it.name }.filterNot(EXECUTION_DIRECTIVES::contains)),
        )
    }

    private fun decodeInlineFragment(
        fragment: InlineFragment,
        typeInScope: GraphQLCompositeType,
        argumentDecoder: ArgumentDecoder,
        mode: TranslationMode,
        fragmentsByName: Map<String, FragmentDefinition>,
    ): SpecSelection.InlineFragment? {
        val typeConditionName = fragment.typeCondition?.name
        val graphQLTypeCondition =
            typeConditionName?.let {
                sourceSchema.getType(it) as GraphQLCompositeType
            }
        val modelTypeCondition =
            typeConditionName?.let { schema.requireType(it) as ViaductSchema.CompositeTypeDef }
        val selections =
            decodeSelectionSet(
                fragment.selectionSet,
                graphQLTypeCondition ?: typeInScope,
                argumentDecoder,
                mode,
                fragmentsByName,
            )
        if (selections.isEmpty()) return null
        return SpecSelection.InlineFragment.of(
            typeCondition = modelTypeCondition,
            selections = selections,
            inclusionCondition = argumentDecoder.decodeCondition(fragment),
        )
    }

    private fun decodeNamedFragment(
        fragment: FragmentDefinition,
        inclusionCondition: InclusionCondition,
        argumentDecoder: ArgumentDecoder,
        mode: TranslationMode,
        fragmentsByName: Map<String, FragmentDefinition>,
    ): SpecSelection.InlineFragment? {
        val typeConditionName = fragment.typeCondition.name!!
        val graphQLTypeCondition =
            sourceSchema.getType(typeConditionName) as GraphQLCompositeType
        val selections =
            decodeSelectionSet(
                fragment.selectionSet,
                graphQLTypeCondition,
                argumentDecoder,
                mode,
                fragmentsByName,
            )
        if (selections.isEmpty()) return null
        return SpecSelection.InlineFragment.of(
            typeCondition = schema.requireType(typeConditionName) as ViaductSchema.CompositeTypeDef,
            selections = selections,
            inclusionCondition = inclusionCondition,
        )
    }

    private sealed interface ArgumentDecoder {
        fun decode(
            field: Field,
            fieldDefinition: GraphQLFieldDefinition,
        ): Map<String, Any?>

        fun decodeCondition(container: DirectivesContainer<*>): InclusionCondition
    }

    private enum class TranslationMode {
        EXTERNAL_OPERATION,
        INTERNAL_FRAGMENT,
    }

    private inner class LiteralArgumentDecoder : ArgumentDecoder {
        override fun decode(
            field: Field,
            fieldDefinition: GraphQLFieldDefinition,
        ): Map<String, Any?> {
            val suppliedArguments = field.arguments.associateBy { it.name }
            return fieldDefinition.arguments
                .mapNotNull { argumentDefinition ->
                    val suppliedArgument = suppliedArguments[argumentDefinition.name]
                    when {
                        suppliedArgument != null ->
                            argumentDefinition.name to
                                decodeLiteral(
                                    type = argumentDefinition.type,
                                    value = suppliedArgument.value,
                                    variableValues = variableValues,
                                    schema = schema,
                                    variableTarget = variableTarget,
                                )
                        argumentDefinition.hasSetDefaultValue() ->
                            argumentDefinition.name to
                                decodeInputValue(
                                    argumentDefinition.type,
                                    argumentDefinition.argumentDefaultValue,
                                    variableValues,
                                    schema,
                                    variableTarget,
                                )
                        else -> null
                    }
                }.toMap()
        }

        override fun decodeCondition(container: DirectivesContainer<*>): InclusionCondition =
            container.directives.filter { it.name in CONDITIONAL_DIRECTIVES }.fold(
                InclusionCondition.Always as InclusionCondition,
            ) { accumulated, directive ->
                val value = directive.arguments.single { it.name == "if" }.value
                val required = directive.name == "include"
                val condition =
                    when (value) {
                        is BooleanValue ->
                            if (value.isValue == required) {
                                InclusionCondition.Always
                            } else {
                                InclusionCondition.Never
                            }
                        is VariableReference -> {
                            val bound = variableValues[value.name]
                            when {
                                variableValues.containsKey(value.name) ->
                                    if (
                                        requireNotNull(bound as? Boolean) {
                                            "Directive variable ${value.name} must be Boolean"
                                        } == required
                                    ) {
                                        InclusionCondition.Always
                                    } else {
                                        InclusionCondition.Never
                                    }
                                else ->
                                    InclusionCondition.requires(
                                        mapOf(
                                            Arguments.Variable.of(
                                                requireNotNull(variableTarget) {
                                                    "Unbound fragment variable \$${value.name} requires an explicit resolver target"
                                                },
                                                value.name,
                                            ) to required,
                                        ),
                                    )
                            }
                        }
                        else -> error("Directive @${directive.name}(if:) must be Boolean")
                    }
                accumulated.and(condition)
            }
    }

    private inner class CoercedArgumentDecoder(
        private val variables: CoercedVariables,
        private val graphQLContext: GraphQLContext,
        private val locale: Locale,
    ) : ArgumentDecoder {
        override fun decode(
            field: Field,
            fieldDefinition: GraphQLFieldDefinition,
        ): Map<String, Any?> {
            val values =
                ValuesResolver.getArgumentValues(
                    sourceSchema.codeRegistry,
                    fieldDefinition.arguments,
                    field.arguments,
                    variables,
                    graphQLContext,
                    locale,
                )
            return fieldDefinition.arguments
                .mapNotNull { argumentDefinition ->
                    if (argumentDefinition.name !in values) {
                        null
                    } else {
                        argumentDefinition.name to
                            decodeExternalInputValue(
                                type = argumentDefinition.type,
                                value = values[argumentDefinition.name],
                                schema = schema,
                            )
                    }
                }.toMap()
        }

        override fun decodeCondition(container: DirectivesContainer<*>): InclusionCondition {
            return if (
                ConditionalNodes().shouldInclude(
                    container,
                    variables.toMap(),
                    sourceSchema,
                    graphQLContext,
                )
            ) {
                InclusionCondition.Always
            } else {
                InclusionCondition.Never
            }
        }
    }

    private companion object {
        val CONDITIONAL_DIRECTIVES = setOf("skip", "include")
        val EXECUTION_DIRECTIVES = CONDITIONAL_DIRECTIVES + "defer"

        val STANDALONE_FRAGMENT_ERRORS =
            setOf(
                ValidationErrorType.UnusedFragment,
                ValidationErrorType.UndefinedVariable,
            )
    }
}

internal data class ParsedSpecFragment(
    val nominalType: ViaductSchema.CompositeTypeDef,
    val selections: List<SpecSelection>,
    private val schema: ViaductSchema,
) {
    val fragment: Fragment by lazy {
        Fragment.of(nominalType, flattenForMaterialization(schema, nominalType, selections))
    }
}

/** Generic no-argument field directives retained by the parser. */
private class ParsedFieldDirectives(
    directiveNames: List<String>,
) : FieldDirectives {
    private val names = directiveNames.toSet()

    override fun hasDirective(
        name: String,
        args: ((Map<String, Any?>) -> Boolean)?,
    ): Boolean = name in names && (args == null || args(emptyMap()))
}
